const AutoDM = require("./src/AutoDM.js");

console.log("App started successfully 🙌🙌");

AutoDM();
